Tetran Advanced
By Metarex Master

This is a boss based off of Tetran from gradius. It utilizes many of its attacks used in the game, and closely resembles it. This one is different from the Tetran-like boss already included in Fraxy, just so you know. It also includes options with it for your player ship.
To be battled in Area Fixed mode with the screensize at 640X480.