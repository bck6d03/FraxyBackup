In order to use this, you must follow these instructions.

1	First put this into your Fraxy map. NOT YOUR ENEMIES MAP!
2	Now, open Config.exe. Select the FreePlay tab, and put the name of this map next to "Random folder"
	instead of the one currently there.
3	Now, change Appear Position to Random.
4	Be sure to check off Area fixed mode!
5	Open Fraxy.exe.
6	Select Free Play, and then Option.
7	Change Enemy count to max 4 sets.
8	Well done! You're ready to go!